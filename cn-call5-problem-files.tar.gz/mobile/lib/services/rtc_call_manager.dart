// ignore_for_file: avoid_print

import 'package:shared_preferences/shared_preferences.dart';
import 'dart:async';
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/services.dart';

import 'package:uuid/uuid.dart';

import 'call_session.dart';
import 'livekit_call.dart';
import 'livekit_token_service.dart';

enum CallState {
  incoming,
  ringing,
  accepted,
  negotiating,
  rejected,
  cancelled,
  connecting,
  connected,
  ended,
  timeout,
  offline,
}

class RtcCallManager {
  RtcCallManager._();

  static final RtcCallManager instance = RtcCallManager._();

  final CallSession session = CallSession.instance;
  final LiveKitCall livekit = LiveKitCall();

  Timer? _ringTimeoutTimer;
  Timer? _negotiationTimeoutTimer;
  Timer? _connectionTimeoutTimer;

  StreamSubscription<Map<String, dynamic>>? _subscription;

  String? remoteUserId;
  String? currentCallId;
  bool? remoteOnline;
  CallState? state;
  bool inCall = false;
  bool caller = false;

  final List<Map<String, dynamic>> _pendingIceCandidates = [];

  Function()? onConnected;
  Function()? onDisconnected;
  Function(Map<String, dynamic> message)? onIncomingCall;
  Function(String callId)? onRemoteCallCancelled;
  Function(bool online)? onRemoteAvailabilityChanged;

  bool _started = false;
  bool _hangingUp = false;
  Future<void>? _cleanupFuture;
  final AudioPlayer _ringbackPlayer = AudioPlayer();
  bool _ringbackPlaying = false;
  Completer<bool>? _callStartCompleter;
  int? _callStartExpiresAt;

  Future<void> _startRinging({
    required String callId,
    int? expiresAt,
  }) async {
    _ringTimeoutTimer?.cancel();

    Duration duration = const Duration(seconds: 90);

    if (expiresAt != null) {
      final remainingMs = expiresAt - DateTime.now().millisecondsSinceEpoch;

      if (remainingMs <= 0) {
        await _handleRingTimeout(callId);
        return;
      }

      final cappedMs = remainingMs > 90000 ? 90000 : remainingMs;
      duration = Duration(milliseconds: cappedMs);
    }

    _ringTimeoutTimer = Timer(
      duration,
      () => _handleRingTimeout(callId),
    );

    try {
      await _ringbackPlayer.stop();
      await _ringbackPlayer.setReleaseMode(ReleaseMode.loop);
      await _ringbackPlayer.play(
        AssetSource('sounds/ringing.mp3'),
      );
      _ringbackPlaying = true;

      print(
        '[CN CALL][RINGBACK START] call_id=$callId asset=sounds/ringing.mp3',
      );
    } catch (e) {
      _ringbackPlaying = false;

      print(
        '[CN CALL][RINGBACK FAILED] call_id=$callId error=$e',
      );
    }
  }

  Future<void> _stopRinging() async {
    _ringTimeoutTimer?.cancel();
    _ringTimeoutTimer = null;

    if (_ringbackPlaying) {
      try {
        await _ringbackPlayer.stop();
      } catch (e) {
        print('[CN CALL][RINGBACK STOP FAILED] error=$e');
      }

      _ringbackPlaying = false;
      print('[CN CALL][RINGBACK STOP]');
    }
  }

  void _cancelCallTimeouts() {
    _ringTimeoutTimer?.cancel();
    _ringTimeoutTimer = null;
    _negotiationTimeoutTimer?.cancel();
    _negotiationTimeoutTimer = null;
    _connectionTimeoutTimer?.cancel();
    _connectionTimeoutTimer = null;
  }

  void _startNegotiationTimeout(String callId) {
    _negotiationTimeoutTimer?.cancel();
    _negotiationTimeoutTimer = Timer(
      const Duration(seconds: 30),
      () => _handleNegotiationTimeout(callId),
    );
  }

  void _startConnectionTimeout(String callId) {
    _connectionTimeoutTimer?.cancel();
    _connectionTimeoutTimer = Timer(
      const Duration(seconds: 30),
      () => _handleConnectionTimeout(callId),
    );
  }

  Future<void> _handleNegotiationTimeout(String callId) async {
    if (!_isCurrentCall(callId) ||
        state == CallState.connected ||
        state == CallState.ended) {
      return;
    }

    print('[CN CALL][TIMEOUT] negotiation call_id=$callId');
    await _cleanupCall(
      reason: 'timeout',
      sendSignal: true,
      signalType: 'hangup',
    );
  }

  Future<void> _handleConnectionTimeout(String callId) async {
    if (!_isCurrentCall(callId) ||
        state == CallState.connected ||
        state == CallState.ended) {
      return;
    }

    print('[CN CALL][TIMEOUT] connection call_id=$callId');
    await _cleanupCall(
      reason: 'timeout',
      sendSignal: true,
      signalType: 'hangup',
    );
  }

  Future<void> _handleRingTimeout(String callId) async {
    if (!_isCurrentCall(callId) || !caller || inCall) return;

    print('[CN CALL][RING] timeout reached');

    await _cleanupCall(
      reason: 'timeout',
      sendSignal: true,
      signalType: 'call_cancelled',
    );
  }

  void startListening() {
    if (_started) return;
    _started = true;

    _subscription = session.socket.messages.listen(_handleMessage);

    livekit.onConnected = () {
      final connectedCallId = currentCallId;
      final target = remoteUserId;

      if (_hangingUp || connectedCallId == null || connectedCallId.isEmpty) {
        return;
      }

      _cancelCallTimeouts();
      inCall = true;
      state = CallState.connected;

      print(
        '[CN CALL][LIVEKIT MANAGER] connected '
        'call_id=$connectedCallId',
      );

      if (connectedCallId.isNotEmpty &&
          target != null &&
          target.isNotEmpty &&
          session.loggedIn &&
          session.socket.connected) {
        unawaited(session.socket.sendGuaranteed({
          'type': 'connected',
          'call_id': connectedCallId,
          'target_id': target,
          'from_id': session.userId,
        }));
      }

      onConnected?.call();
    };

    livekit.onDisconnected = () {
      if (_hangingUp) return;

      print('[CN CALL][LIVEKIT CONNECT FAILED] call_id=$currentCallId disconnected');

      unawaited(
        _cleanupCall(reason: 'failed', sendSignal: true, signalType: 'hangup'),
      );
    };
  }

  Future<void> _handleMessage(Map<String, dynamic> message) async {
    final type = message['type']?.toString();
    final messageCallId = message['call_id']?.toString().trim();

    if (type == 'call') {
      if (messageCallId == null ||
          messageCallId.isEmpty ||
          await session.isCallEnded(messageCallId) ||
          currentCallId != null) {
        return;
      }
      currentCallId = messageCallId;
      await session.markCallActive(messageCallId);
      state = CallState.incoming;
      remoteUserId = message['from_id']?.toString();

      print('[CN CALL][CALL RECEIVE] call_id=$messageCallId from=$remoteUserId');

      onIncomingCall?.call(message);
      return;
    }

    if (type == 'call_started') {
      if (!_isCurrentCall(messageCallId)) return;

      remoteOnline = message['target_online'] == true;
      onRemoteAvailabilityChanged?.call(remoteOnline!);

      // Offline does NOT mean the call failed.
      // The server has already created the call and sent FCM.
      // Keep the caller ringing until the server-provided 90s expiry.
      state = CallState.ringing;
      print('[CN CALL][CALL UI RINGING] call_id=$messageCallId');

      final expiresAtRaw = message['ring_expires_at'];
      _callStartExpiresAt = expiresAtRaw is int
          ? expiresAtRaw
          : int.tryParse(expiresAtRaw?.toString() ?? '');

      await _startRinging(callId: messageCallId!, expiresAt: _callStartExpiresAt);

      // call_started itself confirms that the server accepted the call.
      // target_online only tells us whether the target has a live WebSocket.
      _callStartCompleter?.complete(true);
      _callStartCompleter = null;

      return;
    }

    if (type == 'call_accept') {
      if (!_isCurrentCall(messageCallId)) return;
      print('[CN CALL][CALL ACCEPT FORWARD] call_id=$messageCallId');
      await _handleAccepted();
      return;
    }

    if (type == 'call_cancelled') {
      await handleRemoteTermination(callId: messageCallId, reason: 'cancelled');
      return;
    }

    if (type == 'hangup' || type == 'call_reject') {
      await handleRemoteTermination(
        callId: messageCallId,
        reason: type == 'call_reject' ? 'rejected' : 'ended',
      );
      return;
    }
  }

  /// Handles a terminal event from WebSocket or FCM exactly once at the call
  /// state boundary.  Persisting the tombstone before touching native UI makes
  /// late `incoming_call` pushes, reconnects and pending-call restoration
  /// harmless.
  Future<void> handleRemoteTermination({
    required String? callId,
    required String reason,
  }) async {
    final id = callId?.trim() ?? '';
    if (id.isEmpty) return;

    await session.markCallEnded(id);
    await session.clearPendingIncomingCall(id);

    try {
      const telecomChannel = MethodChannel('cn_call/call');
      await telecomChannel.invokeMethod(
        'disconnectTelecomCall',
        <String, dynamic>{
          'callId': id,
        },
      );
      print(
        '[CN CALL][TELECOM] remote call disconnected '
        'call_id=$id',
      );
    } catch (e) {
      print(
        '[CN CALL][TELECOM] remote disconnect failed: $e',
      );
    }

    if (reason == 'cancelled') {
      onRemoteCallCancelled?.call(id);
    }

    if (!_isCurrentCall(id)) return;

    await _cleanupCall(reason: reason);
  }

  bool _isCurrentCall(String? callId) {
    return callId != null && callId.isNotEmpty && callId == currentCallId;
  }

  Future<bool> startCall({
    required String targetId,
    String? callId,
  }) async {
    final myId = session.userId;
    if (myId == null || targetId == myId) return false;

    if (currentCallId != null || inCall) return false;

    remoteUserId = targetId;

    final suppliedCallId = callId?.trim() ?? '';
    currentCallId = suppliedCallId.isNotEmpty
        ? suppliedCallId
        : const Uuid().v4();

    if (currentCallId == null || currentCallId!.isEmpty) {
      return false;
    }
    state = CallState.ringing;
    caller = true;
    inCall = false;
    remoteOnline = null;
    onRemoteAvailabilityChanged?.call(false);
    await session.markCallActive(currentCallId!);
    _pendingIceCandidates.clear();

    try {
      await session.ensureSocketReady();
    } catch (error) {
      await _cleanupCall(reason: 'failed');
      return false;
    }
    _callStartCompleter = Completer<bool>();
    await session.socket.sendGuaranteed({
      'type': 'call',
      'call_id': currentCallId,
      'target_id': targetId,
      'caller_name': session.displayName ?? 'Hesam',
      'from_id': myId,
    });

    return true;
  }

  Future<void> acceptCall({required String callerId, String? callId}) async {
    final acceptedCallId = callId ?? currentCallId;
    if (acceptedCallId == null ||
        await session.isCallEnded(acceptedCallId) ||
        (currentCallId != null && currentCallId != acceptedCallId)) {
      return;
    }
    if (state == CallState.accepted ||
        state == CallState.connecting ||
        state == CallState.connected) {
      return;
    }

    print('[CN CALL][CALL ANSWER RECEIVED] call_id=$acceptedCallId');
    remoteUserId = callerId;
    currentCallId = callId ?? currentCallId;
    await session.markCallActive(currentCallId!);
    state = CallState.accepted;
    caller = false;
    inCall = false;
    _pendingIceCandidates.clear();

    try {
      // A cold Telecom action has to restore and await the same signalling
      // socket used by outgoing calls. Never silently drop call_accept.
      await session.ensureSocketReady();
      if (!_isCurrentCall(acceptedCallId)) return;
      print('[CN CALL][CALL SOCKET READY] call_id=$acceptedCallId');
      await session.socket.sendGuaranteed({
        'type': 'call_accept',
        'call_id': acceptedCallId,
        'target_id': callerId,
      });
      print('[CN CALL][CALL_ACCEPT SENT] call_id=$acceptedCallId');
      state = CallState.negotiating;
      _startNegotiationTimeout(acceptedCallId);
      _startConnectionTimeout(acceptedCallId);
      await _connectLiveKit(currentCallId!);
    } catch (e) {
      print('[CN CALL][LIVEKIT CONNECT FAILED] call_id=$acceptedCallId error=$e');
      await _failTelecomAndCleanup(acceptedCallId, reason: 'failed');
    }
  }

  Future<void> _handleAccepted() async {
    if (!caller) return;
    if (state == CallState.connecting || state == CallState.connected) return;

    await _stopRinging();

    final acceptedCallId = currentCallId;
    if (acceptedCallId == null || acceptedCallId.isEmpty) return;

    state = CallState.negotiating;

    try {
      await _connectLiveKit(acceptedCallId);
    } catch (e) {
      print('[CN CALL][LIVEKIT CONNECT FAILED] call_id=$acceptedCallId error=$e');
      await _failTelecomAndCleanup(acceptedCallId, reason: 'failed');
    }
  }

  Future<void> rejectCall({required String callerId, String? callId}) async {
    final rejectedCallId = callId?.trim() ?? '';
    final rejectedCallerId = callerId.trim();
    if (rejectedCallId.isEmpty ||
        rejectedCallerId.isEmpty ||
        await session.isCallEnded(rejectedCallId)) {
      return;
    }
    if (currentCallId != null && currentCallId != rejectedCallId) return;
    if (remoteUserId != null && remoteUserId != rejectedCallerId) return;

    // A Telecom action can launch Flutter after the process was terminated.
    // Rehydrate only this exact call so cleanup sends its reject to the right
    // peer; a stale action can never clean up a newer call.
    currentCallId ??= rejectedCallId;
    remoteUserId ??= rejectedCallerId;
    caller = false;
    inCall = false;
    state = CallState.incoming;
    await session.markCallActive(rejectedCallId);

    await _cleanupCall(
      reason: 'rejected',
      sendSignal: true,
      signalType: 'call_reject',
    );
  }

  Future<void> hangup({bool sendSignal = true}) async {
    final shouldCancel = caller && !inCall;
    await _cleanupCall(
      reason: shouldCancel ? 'cancelled' : 'ended',
      sendSignal: sendSignal,
      signalType: shouldCancel ? 'call_cancelled' : 'hangup',
    );
  }

  Future<void> endForSession({bool sendSignal = true}) {
    return _cleanupCall(
      reason: 'ended',
      sendSignal: sendSignal,
      signalType: 'hangup',
    );
  }

  Future<void> _cleanupCall({
    required String reason,
    bool sendSignal = false,
    String? signalType,
  }) async {
    if (_hangingUp) return _cleanupFuture ?? Future<void>.value();

    _hangingUp = true;
    final callId = currentCallId;
    final target = remoteUserId;

    final cleanup = () async {
      print('[CN CALL][CALL CLEANUP START] call_id=$callId reason=$reason');
      try {
      _callStartCompleter?.complete(false);
      _callStartCompleter = null;
      _callStartExpiresAt = null;
      _cancelCallTimeouts();
      await _stopRinging();

      if (sendSignal && callId != null && target != null && session.loggedIn) {
        try {
          // Terminal control messages must get a real ready handshake too;
          // dropping them because a reconnect has just started leaves the
          // other Samsung UI ringing until timeout.
          await session.ensureSocketReady();
          await session.socket.sendGuaranteed({
            'type': signalType ?? 'hangup',
            'call_id': callId,
            'target_id': target,
          });
          print('[CN CALL][CALL TERMINAL] call_id=$callId type=${signalType ?? 'hangup'}');
        } catch (error) {
          print('[CN CALL][CALL TERMINAL SEND FAILED] call_id=$callId error=$error');
        }
      }

      await livekit.disconnect();

      if (callId != null && callId.isNotEmpty) {
        try {
          const telecomChannel = MethodChannel('cn_call/call');
          await telecomChannel.invokeMethod('disconnectTelecomCall', {'callId': callId});
        } catch (error) {
          print('[CN CALL][TELECOM] local disconnect failed: $error');
        }
      }

      if (callId != null && callId.isNotEmpty) {
        final prefs = await SharedPreferences.getInstance();

        await prefs.setString(
          'cn_call_telecom_ended_call_id',
          callId,
        );

        final activeId = prefs.getString(
          'cn_call_telecom_active_call_id',
        );

        if (activeId == callId) {
          await prefs.remove(
            'cn_call_telecom_active_call_id',
          );
        }

      }

      await session.markCallEnded(callId);
      await session.clearPendingIncomingCall(callId);

      _pendingIceCandidates.clear();
      remoteUserId = null;
      currentCallId = null;
      remoteOnline = null;
      inCall = false;
      caller = false;
      state = switch (reason) {
        'cancelled' => CallState.cancelled,
        'rejected' => CallState.rejected,
        'timeout' => CallState.timeout,
        'failed' => CallState.ended,
        _ => CallState.ended,
      };

      if (callId != null) onDisconnected?.call();
      print('[CN CALL][CALL CLEANUP DONE] call_id=$callId reason=$reason');
      } finally {
        _hangingUp = false;
        _cleanupFuture = null;
      }
    }();
    _cleanupFuture = cleanup;
    return cleanup;
  }

  Future<void> mute(bool value) {
    return livekit.mute(value);
  }

  Future<void> setSpeaker(bool value) {
    return livekit.setSpeaker(value);
  }

  Future<void> dispose() async {
    await _cleanupCall(reason: 'ended', sendSignal: true);
    await _subscription?.cancel();
    _subscription = null;
    _started = false;

    await livekit.disconnect();
  }

  Future<void> _connectLiveKit(String callId) async {
    print('[CN CALL][LIVEKIT START] call_id=$callId');

    final data = await LiveKitTokenService.getToken(callId: callId);

    final url = data['url']?.toString();
    final token = data['token']?.toString();

    if (url == null || url.isEmpty) {
      throw Exception('LiveKit response missing url');
    }

    if (token == null || token.isEmpty) {
      throw Exception('LiveKit response missing token');
    }

    await livekit.connect(url: url, token: token);
    print('[CN CALL][LIVEKIT CONNECTED] call_id=$callId');

    if (!_isCurrentCall(callId)) {
      await livekit.disconnect();
      throw StateError('LiveKit connected for a stale call');
    }

    final prefs = await SharedPreferences.getInstance();

    await prefs.setString(
      'cn_call_telecom_active_call_id',
      callId,
    );

    await prefs.remove(
      'cn_call_telecom_ended_call_id',
    );

    print(
      '[CN CALL][TELECOM] LiveKit connected call_id=$callId',
    );
    try {
      const telecomChannel = MethodChannel('cn_call/call');
      final activated = await telecomChannel.invokeMethod<bool>(
            'activateTelecomCall',
            {'callId': callId},
          ) ??
          false;
      if (!activated) throw StateError('Telecom connection is unavailable');
      livekit.notifyConnected();
      print('[CN CALL][TELECOM ACTIVE] call_id=$callId');
    } catch (_) {
      rethrow;
    }
  }

  Future<void> endFromTelecom({
    required String callId,
    required String reason,
  }) async {
    final id = callId.trim();
    if (id.isEmpty) return;

    /*
     * Telecom already confirmed the terminal state before dispatching
     * this event. Flutter must only reconcile its own signaling/media
     * state here. It must NOT send another Telecom disconnect request.
     */
    await session.markCallEnded(id);
    await session.clearPendingIncomingCall(id);

    if (!_isCurrentCall(id)) {
      return;
    }

    if (_hangingUp) {
      return;
    }

    _cancelCallTimeouts();
    await _stopRinging();

    try {
      await livekit.disconnect();
    } catch (error) {
      print(
        '[CN CALL][LIVEKIT] terminal disconnect failed '
        'call_id=$id error=$error',
      );
    }

    _pendingIceCandidates.clear();
    remoteUserId = null;
    currentCallId = null;
    remoteOnline = null;
    inCall = false;
    caller = false;
    state = switch (reason) {
      'cancelled' => CallState.cancelled,
      'rejected' => CallState.rejected,
      'timeout' => CallState.timeout,
      'failed' => CallState.ended,
      _ => CallState.ended,
    };

    onDisconnected?.call();

    print(
      '[CN CALL][CALL TERMINAL RECONCILED] '
      'call_id=$id reason=$reason',
    );
  }


  Future<void> _failTelecomAndCleanup(String callId, {required String reason}) async {
    try {
      const telecomChannel = MethodChannel('cn_call/call');
      await telecomChannel.invokeMethod('failTelecomCall', {'callId': callId});
    } catch (error) {
      print('[CN CALL][TELECOM] failure disconnect failed: $error');
    }
    await _cleanupCall(reason: reason, sendSignal: true, signalType: 'hangup');
  }
}
